(function($) {
	"use strict";	
	const ps = new PerfectScrollbar('.cart-scroll', {
		useBothWheelAxes:true,
		suppressScrollX:true,
	});
	
	const ps1 = new PerfectScrollbar('.notify-scroll', {
		useBothWheelAxes:true,
		suppressScrollX:true,
	});
	
	const ps2 = new PerfectScrollbar('.message-scroll', {
		useBothWheelAxes:true,
		suppressScrollX:true,
	});
	
	const ps3 = new PerfectScrollbar('.profile-scroll', {
		useBothWheelAxes:true,
		suppressScrollX:true,
	});
	
})(jQuery);