
var keywords = [
	'HTML','HTML Admin','HTML Corporate','HTML Creative','HTML Mobile','HTML Personal','HTML Technologies','HTML Wedding',
	'Wordpress','Wordpress Admin','Wordpress Corporate','Wordpress Creative','Wordpress Mobile','Wordpress Personal','Wordpress Technologies','Wordpress Wedding',
	'PHP','PHP Admin','PHP Corporate','PHP Creative','PHP Mobile','PHP Personal','PHP Technologies','PHP Wedding',
	'Angular','Angular Admin','Angular Corporate','Angular Creative','Angular Mobile','Angular Personal','Angular Technologies','Angular Wedding',
	'Angular','Angular Admin','Angular Corporate','Angular Creative','Angular Mobile','Angular Personal','Angular Technologies','Angular Wedding','plugins'
];
$('.keywords-input').autocomplete({
	source:[keywords]
});
