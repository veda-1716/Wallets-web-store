================================================================================
This Project Developed By SPRUKO TECHNOLOGIES PRIVATE LIMITED.
================================================================================

By downloading, installing, or using this Template/Application/Code, you agree to be bound by the terms and conditions of the license agreement that applies to your use of this product. You must validly acquire a license in order to use this product. If you have purchased a regular license, you may use this product in accordance with the terms of the regular license agreement. If you have purchased an extended license, you may use this product in accordance with the terms of the extended license agreement. You are not authorized to use this Template/Application/Code if you have not validly acquired a license.

Please carefully read and understand the terms of your license agreement, which can be found at https://themeforest.net/licenses/standard or https://spruko.com/licenses-details. If you have any questions or concerns regarding your license or use of this product, please you can contact the sales support email, which is support@team.spruko.com.

By using this Template/Application/Code, you acknowledge that you have read this license agreement, understand it, and agree to be bound by its terms and conditions.

================================================================================
SPRUKO™ SUPPORT
================================================================================

If you have any other queries related to support, we recommend visiting our knowledge base to solve any issues or technical questions before opening a tech support request. 
If you still need assistance, please open a tech support request using the following link: https://support.spruko.com.

================================================================================
PRE-SALES
================================================================================

if you have any questions or queries related to pre-sales support, you can contact the sales support email, which is support@team.spruko.com.

================================================================================
Disclaimer : 
================================================================================
Our all items subject to themeforest and codecanyon licensing.
Please refer to license details the above information is summary only.
https://themeforest.net/licenses/standard


================================================================================
This project is protected by copyright law and international treaties.
================================================================================

Unauthorized license usage,YOU or YOUR CLIENT, as well as unauthorized reproduction or redistribution of this product, software, or any of its components may result in severe civil and criminal penalties, 
and will be prosecuted to the fullest extent permitted by law. 
Our Legal Team is Always ready to send takedown notices based on DMCA Act (Digital Millennium Copyright Act ) in removing content from the internet..


Our Legal Team is always ready to send a DMCA takedown notice to any service provider associated with the infringing content anytime, without any notice. 
Including the Website Hosting Company, Domain Company,Server Company, Youtube, Payment Gateway Companies, or any online ad networks like Google's AdSense,Social ad networks and search engines showing the content in their search results.

It also criminalizes the act of circumventing an access control, whether or not there is actual infringement of copyright itself. In addition, the DMCA heightens the penalties for copyright infringement on the Internet.

After sending a DMCA notice to your service providers. If no one responds from your company. In that case your company's services will be suspended.

The Digital Millennium Copyright Act : https://www.copyright.gov/dmca/
